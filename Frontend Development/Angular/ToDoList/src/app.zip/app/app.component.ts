import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faCoffee } from '@fortawesome/free-solid-svg-icons';
import { faTrash } from '@fortawesome/free-solid-svg-icons';
import {FormsModule} from '@angular/forms';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet,FontAwesomeModule,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'ToDoList';
  faCoffee = faCoffee;
  faTrash = faTrash;




  taskList:{id:number; task:string}[]=[];
  task:string="";



  
  addTask(){

    if(this.task){
      console.log("TaskAdded");
      this.taskList.push({id:this.taskList.length+1, task:this.task});
      this.task="";
    }
  }

  deleteTask(id: number) {
    this.taskList = this.taskList.filter(task => task.id !== id);
  }



}
