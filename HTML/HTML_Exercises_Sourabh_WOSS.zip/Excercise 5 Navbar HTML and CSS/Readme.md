# Excercise 5 with HTML and CSS in horizontal navbar:Create webpage that conatins menu(home, about ,services,contact us) using ul li and a tag. 

THis is to demonstrate a Navbar in HTML and with minimal css.