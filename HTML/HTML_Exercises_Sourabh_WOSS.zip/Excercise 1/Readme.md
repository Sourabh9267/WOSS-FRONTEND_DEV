# Excersice 1: Display Hello World!

task is to display simple Hello World! using HTML.