# Excercise 2: Create a web page which displays your personal details in the below format:

personal Information
Name: xxxx
Gender: xxxx
e-mail ID: xxxx
Mob.No.: xxxx
Xth Percentage: xx
Inter Percentage: xx
Aggregate Percentage in B.Tech: xx"

## This excercise demonstrates what i've learned so far.


 from the very beginning Introduction to HTML - Heaadings, Paragraphs, Links, Styles, Lists, Text Formmatting etc