# Excercise 5 :Create webpage that conatins menu(home, about ,services,contact us) using ul li and a tag.

THis is to demonstrate a Navbar in HTML