# Excercise 4: Create a web page which displays a hyperlink for each subject in your current semester. When the user clicks a link, it should open the respective subject's page. (Note: The subject pages can be empty).


This illustrates the use of anchor tag with relative and absolute url to show the demo pages.

