# Excercise 3: Create a web page which displays the syllabus of XXX as a bulleted list. Unit titles are displayed as contents of the main list and the topics of individual units are displayed as sub lists in the main list. (Hint: Use nested lists)

this excercise demonstrated with OOPM RGPV Sylllbus

Introduction to Object Oriented Thinking & Object Oriented Programming: Comparison with Procedural Programming, features of Object oriented paradigm– Merits and demerits of OO methodology; Object model; Elements of OOPS, IO processing.